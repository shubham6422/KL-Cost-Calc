package com.costcalc.kl;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.FirebaseApp;
import java.io.*;
import java.text.*;
import java.text.DecimalFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.regex.*;
import org.json.*;

public class CalcActivity extends AppCompatActivity {
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private double lengthnum = 0;
	private double widthnum = 0;
	private double thiknum = 0;
	private double ratenum = 0;
	private double weight = 0;
	private double totalmatcost = 0;
	private double materialcost = 0;
	private double pathLengthnum = 0;
	private double labourThik = 0;
	private double labourRate = 0;
	private double labourStartPoint = 0;
	private double labourCost = 0;
	private double totalcostofquotation = 0;
	private double bendingCost = 0;
	private double other_charges = 0;
	private double bend_qty = 0;
	private double bend_rate = 0;
	private double totalbendrate = 0;
	private double fab_cost = 0;
	private double powdercoat_cost = 0;
	private double sqft = 0;
	private double powdercoating_cost = 0;
	private double powcoat_rate = 0;
	
	private ArrayList<String> material_list = new ArrayList<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear2;
	private TextView textview12;
	private LinearLayout box;
	private LinearLayout box2;
	private LinearLayout box3;
	private LinearLayout linear48;
	private LinearLayout box4;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear53;
	private Spinner spinner1;
	private LinearLayout linear9;
	private EditText length;
	private TextView textview6;
	private LinearLayout linear10;
	private EditText width;
	private TextView textview7;
	private LinearLayout linear11;
	private EditText thik;
	private TextView textview8;
	private LinearLayout linear12;
	private EditText rate;
	private TextView textview9;
	private LinearLayout linear13;
	private TextView weighttxt;
	private TextView textview10;
	private LinearLayout linear54;
	private TextView sqfttxt;
	private TextView textview33;
	private LinearLayout linear15;
	private LinearLayout linear16;
	private LinearLayout linear17;
	private LinearLayout linear18;
	private LinearLayout linear19;
	private LinearLayout linear25;
	private LinearLayout linear20;
	private EditText pathLengthtxt;
	private TextView textview13;
	private LinearLayout linear21;
	private EditText labourThiktxt;
	private TextView textview14;
	private LinearLayout linear22;
	private EditText labourRatetxt;
	private TextView textview15;
	private LinearLayout linear23;
	private EditText labourStartPointtxt;
	private TextView textview16;
	private LinearLayout linear24;
	private TextView labourCosttxt;
	private TextView textview18;
	private CheckBox spCostOne;
	private CheckBox alu_checkbox;
	private CheckBox totmatcostcheck;
	private LinearLayout linear27;
	private LinearLayout linear28;
	private LinearLayout linear32;
	private EditText bendqtytxt;
	private TextView textview19;
	private LinearLayout linear33;
	private EditText bendratetxt;
	private TextView textview20;
	private LinearLayout linear49;
	private LinearLayout linear50;
	private LinearLayout linear51;
	private EditText fabcost;
	private TextView textview31;
	private LinearLayout linear52;
	private EditText powcost;
	private TextView textview32;
	private LinearLayout linear38;
	private LinearLayout linear39;
	private LinearLayout linear57;
	private LinearLayout linear55;
	private LinearLayout linear40;
	private LinearLayout linear41;
	private LinearLayout linear42;
	private LinearLayout linear59;
	private Button button2;
	private LinearLayout linear43;
	private TextView matcostext;
	private TextView textview25;
	private LinearLayout linear44;
	private TextView labourcosttotal;
	private TextView textview26;
	private LinearLayout linear58;
	private TextView fabtext;
	private TextView textview35;
	private LinearLayout linear56;
	private TextView powcoattext;
	private TextView textview36;
	private LinearLayout linear45;
	private TextView bendingcost;
	private TextView textview27;
	private LinearLayout linear46;
	private EditText othercharges;
	private TextView textview28;
	private LinearLayout linear47;
	private TextView totalcost;
	private TextView textview30;
	private TextView part_name;
	
	private SharedPreferences material;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.calc);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		vscroll1 = findViewById(R.id.vscroll1);
		linear2 = findViewById(R.id.linear2);
		textview12 = findViewById(R.id.textview12);
		box = findViewById(R.id.box);
		box2 = findViewById(R.id.box2);
		box3 = findViewById(R.id.box3);
		linear48 = findViewById(R.id.linear48);
		box4 = findViewById(R.id.box4);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		linear7 = findViewById(R.id.linear7);
		linear8 = findViewById(R.id.linear8);
		linear53 = findViewById(R.id.linear53);
		spinner1 = findViewById(R.id.spinner1);
		linear9 = findViewById(R.id.linear9);
		length = findViewById(R.id.length);
		textview6 = findViewById(R.id.textview6);
		linear10 = findViewById(R.id.linear10);
		width = findViewById(R.id.width);
		textview7 = findViewById(R.id.textview7);
		linear11 = findViewById(R.id.linear11);
		thik = findViewById(R.id.thik);
		textview8 = findViewById(R.id.textview8);
		linear12 = findViewById(R.id.linear12);
		rate = findViewById(R.id.rate);
		textview9 = findViewById(R.id.textview9);
		linear13 = findViewById(R.id.linear13);
		weighttxt = findViewById(R.id.weighttxt);
		textview10 = findViewById(R.id.textview10);
		linear54 = findViewById(R.id.linear54);
		sqfttxt = findViewById(R.id.sqfttxt);
		textview33 = findViewById(R.id.textview33);
		linear15 = findViewById(R.id.linear15);
		linear16 = findViewById(R.id.linear16);
		linear17 = findViewById(R.id.linear17);
		linear18 = findViewById(R.id.linear18);
		linear19 = findViewById(R.id.linear19);
		linear25 = findViewById(R.id.linear25);
		linear20 = findViewById(R.id.linear20);
		pathLengthtxt = findViewById(R.id.pathLengthtxt);
		textview13 = findViewById(R.id.textview13);
		linear21 = findViewById(R.id.linear21);
		labourThiktxt = findViewById(R.id.labourThiktxt);
		textview14 = findViewById(R.id.textview14);
		linear22 = findViewById(R.id.linear22);
		labourRatetxt = findViewById(R.id.labourRatetxt);
		textview15 = findViewById(R.id.textview15);
		linear23 = findViewById(R.id.linear23);
		labourStartPointtxt = findViewById(R.id.labourStartPointtxt);
		textview16 = findViewById(R.id.textview16);
		linear24 = findViewById(R.id.linear24);
		labourCosttxt = findViewById(R.id.labourCosttxt);
		textview18 = findViewById(R.id.textview18);
		spCostOne = findViewById(R.id.spCostOne);
		alu_checkbox = findViewById(R.id.alu_checkbox);
		totmatcostcheck = findViewById(R.id.totmatcostcheck);
		linear27 = findViewById(R.id.linear27);
		linear28 = findViewById(R.id.linear28);
		linear32 = findViewById(R.id.linear32);
		bendqtytxt = findViewById(R.id.bendqtytxt);
		textview19 = findViewById(R.id.textview19);
		linear33 = findViewById(R.id.linear33);
		bendratetxt = findViewById(R.id.bendratetxt);
		textview20 = findViewById(R.id.textview20);
		linear49 = findViewById(R.id.linear49);
		linear50 = findViewById(R.id.linear50);
		linear51 = findViewById(R.id.linear51);
		fabcost = findViewById(R.id.fabcost);
		textview31 = findViewById(R.id.textview31);
		linear52 = findViewById(R.id.linear52);
		powcost = findViewById(R.id.powcost);
		textview32 = findViewById(R.id.textview32);
		linear38 = findViewById(R.id.linear38);
		linear39 = findViewById(R.id.linear39);
		linear57 = findViewById(R.id.linear57);
		linear55 = findViewById(R.id.linear55);
		linear40 = findViewById(R.id.linear40);
		linear41 = findViewById(R.id.linear41);
		linear42 = findViewById(R.id.linear42);
		linear59 = findViewById(R.id.linear59);
		button2 = findViewById(R.id.button2);
		linear43 = findViewById(R.id.linear43);
		matcostext = findViewById(R.id.matcostext);
		textview25 = findViewById(R.id.textview25);
		linear44 = findViewById(R.id.linear44);
		labourcosttotal = findViewById(R.id.labourcosttotal);
		textview26 = findViewById(R.id.textview26);
		linear58 = findViewById(R.id.linear58);
		fabtext = findViewById(R.id.fabtext);
		textview35 = findViewById(R.id.textview35);
		linear56 = findViewById(R.id.linear56);
		powcoattext = findViewById(R.id.powcoattext);
		textview36 = findViewById(R.id.textview36);
		linear45 = findViewById(R.id.linear45);
		bendingcost = findViewById(R.id.bendingcost);
		textview27 = findViewById(R.id.textview27);
		linear46 = findViewById(R.id.linear46);
		othercharges = findViewById(R.id.othercharges);
		textview28 = findViewById(R.id.textview28);
		linear47 = findViewById(R.id.linear47);
		totalcost = findViewById(R.id.totalcost);
		textview30 = findViewById(R.id.textview30);
		part_name = findViewById(R.id.part_name);
		material = getSharedPreferences("rates", Activity.MODE_PRIVATE);
		
		spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (_position == 0) {
					rate.setText(material.getString("mscr", ""));
				}
				if (_position == 1) {
					rate.setText(material.getString("mshr", ""));
				}
				if (_position == 2) {
					rate.setText(material.getString("ss304", ""));
				}
				if (_position == 3) {
					rate.setText(material.getString("ss316", ""));
				}
				if (_position == 4) {
					rate.setText(material.getString("ss202", ""));
				}
				if (_position == 5) {
					rate.setText(material.getString("alu", ""));
				}
				if (_position == 6) {
					rate.setText(material.getString("gi", ""));
				}
			}
			
			@Override
			public void onNothingSelected(AdapterView<?> _param1) {
				
			}
		});
		
		length.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < length.getText().toString().length()) {
					lengthnum = Double.parseDouble(length.getText().toString());
					_weightCalc();
					_matcost();
					_sqftcalc();
					_powder_coating_cost_calc();
				}
				else {
					lengthnum = 0;
					_weightCalc();
					_matcost();
					_sqftcalc();
					_powder_coating_cost_calc();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		width.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < width.getText().toString().length()) {
					widthnum = Double.parseDouble(width.getText().toString());
					_weightCalc();
					_matcost();
					_sqftcalc();
					_powder_coating_cost_calc();
				}
				else {
					widthnum = 0;
					_weightCalc();
					_matcost();
					_sqftcalc();
					_powder_coating_cost_calc();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		thik.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < thik.getText().toString().length()) {
					thiknum = Double.parseDouble(thik.getText().toString());
					_weightCalc();
					_matcost();
				}
				else {
					thiknum = 0;
					_weightCalc();
					_matcost();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		rate.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < rate.getText().toString().length()) {
					ratenum = Double.parseDouble(rate.getText().toString());
					_matcost();
				}
				else {
					ratenum = 0;
					_matcost();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		pathLengthtxt.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < pathLengthtxt.getText().toString().length()) {
					pathLengthnum = Double.parseDouble(pathLengthtxt.getText().toString());
					_labourCostCalc();
				}
				else {
					pathLengthnum = 0;
					_labourCostCalc();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		labourThiktxt.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < labourThiktxt.getText().toString().length()) {
					labourThik = Double.parseDouble(labourThiktxt.getText().toString());
					_labourCostCalc();
				}
				else {
					labourThik = 0;
					_labourCostCalc();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		labourRatetxt.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < labourRatetxt.getText().toString().length()) {
					labourRate = Double.parseDouble(labourRatetxt.getText().toString());
					_labourCostCalc();
				}
				else {
					labourRate = 0;
					_labourCostCalc();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		labourStartPointtxt.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < labourStartPointtxt.getText().toString().length()) {
					labourStartPoint = Double.parseDouble(labourStartPointtxt.getText().toString());
					_labourCostCalc();
				}
				else {
					labourStartPoint = 0;
					_labourCostCalc();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		spCostOne.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (0 < pathLengthtxt.getText().toString().length()) {
					if (0 < labourThiktxt.getText().toString().length()) {
						if (0 < labourRatetxt.getText().toString().length()) {
							if (0 < labourStartPointtxt.getText().toString().length()) {
								labourStartPoint = Double.parseDouble(labourStartPointtxt.getText().toString());
								_labourCostCalc();
								_totalcostfunc();
							}
							else {
								labourStartPoint = 0;
								_labourCostCalc();
								_totalcostfunc();
							}
							labourRate = Double.parseDouble(labourRatetxt.getText().toString());
							_labourCostCalc();
							_totalcostfunc();
						}
						else {
							labourRate = 0;
							_labourCostCalc();
							_totalcostfunc();
						}
						labourThik = Double.parseDouble(labourThiktxt.getText().toString());
						_labourCostCalc();
						_totalcostfunc();
					}
					else {
						labourThik = 0;
						_labourCostCalc();
						_totalcostfunc();
					}
					pathLengthnum = Double.parseDouble(pathLengthtxt.getText().toString());
					_labourCostCalc();
					_totalcostfunc();
				}
				else {
					pathLengthnum = 0;
					_labourCostCalc();
					_totalcostfunc();
				}
			}
		});
		
		alu_checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				_weightCalc();
				_matcost();
				_totalcostfunc();
			}
		});
		
		totmatcostcheck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (0 < rate.getText().toString().length()) {
					ratenum = Double.parseDouble(rate.getText().toString());
					_weightCalc();
					_matcost();
				}
				else {
					ratenum = 0;
					_weightCalc();
					_matcost();
				}
			}
		});
		
		bendqtytxt.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < bendqtytxt.getText().toString().length()) {
					bend_qty = Double.parseDouble(bendqtytxt.getText().toString());
					_bendcostcalc();
				}
				else {
					bend_qty = 0;
					_bendcostcalc();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		bendratetxt.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < bendratetxt.getText().toString().length()) {
					bend_rate = Double.parseDouble(bendratetxt.getText().toString());
					_bendcostcalc();
				}
				else {
					bend_rate = 0;
					_bendcostcalc();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		fabcost.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < fabcost.getText().toString().length()) {
					fab_cost = Double.parseDouble(fabcost.getText().toString());
					fabtext.setText(String.valueOf(fab_cost));
					_totalcostfunc();
				}
				else {
					fab_cost = 0;
					_totalcostfunc();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		powcost.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < powcost.getText().toString().length()) {
					powcoat_rate = Double.parseDouble(powcost.getText().toString());
					_powder_coating_cost_calc();
					_totalcostfunc();
				}
				else {
					powcoat_rate = 0;
					_totalcostfunc();
					_powder_coating_cost_calc();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		othercharges.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < othercharges.getText().toString().length()) {
					other_charges = Double.parseDouble(othercharges.getText().toString());
					_totalcostfunc();
				}
				else {
					other_charges = 0;
					_totalcostfunc();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
	}
	
	private void initializeLogic() {
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			int clrs [] = {0xFFF0F0F0,0xFFFFFFFF};
			SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, clrs);
			SketchUi.setCornerRadius(d*7);
			box.setElevation(d*23);
			box.setBackground(SketchUi);
		}
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			int clrs [] = {0xFFF0F0F0,0xFFFFFFFF};
			SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, clrs);
			SketchUi.setCornerRadius(d*7);
			box2.setElevation(d*23);
			box2.setBackground(SketchUi);
		}
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			int clrs [] = {0xFFF0F0F0,0xFFFFFFFF};
			SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, clrs);
			SketchUi.setCornerRadius(d*7);
			box3.setElevation(d*23);
			box3.setBackground(SketchUi);
		}
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			int clrs [] = {0xFFF0F0F0,0xFFFFFFFF};
			SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, clrs);
			SketchUi.setCornerRadius(d*7);
			box4.setElevation(d*23);
			box4.setBackground(SketchUi);
		}
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			int clrs [] = {0xFFF0F0F0,0xFFFFFFFF};
			SketchUi= new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, clrs);
			SketchUi.setCornerRadius(d*7);
			linear48.setElevation(d*23);
			linear48.setBackground(SketchUi);
		}
		material_list.add((int)(0), "MSCR");
		material_list.add((int)(1), "MSHR");
		material_list.add((int)(2), "SS304");
		material_list.add((int)(3), "SS316");
		material_list.add((int)(4), "SS202");
		material_list.add((int)(5), "ALUMINIUM ");
		material_list.add((int)(6), "GI");
		spinner1.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, material_list));
		((ArrayAdapter)spinner1.getAdapter()).notifyDataSetChanged();
	}
	
	public void _weightCalc() {
		if (alu_checkbox.isChecked()) {
			weight = (lengthnum / 1000) * ((widthnum / 1000) * ((thiknum / 1000) * 2800));
			weighttxt.setText(new DecimalFormat("0.5").format(weight));
		}
		else {
			weight = (lengthnum / 1000) * ((widthnum / 1000) * ((thiknum / 1000) * 8000));
			weighttxt.setText(String.valueOf(weight));
		}
	}
	
	
	public void _matcost() {
		if (totmatcostcheck.isChecked()) {
			materialcost = ratenum * weight;
			totalmatcost = materialcost + (materialcost * 0.1d);
			matcostext.setText(new DecimalFormat("0.5").format(totalmatcost));
			_totalcostfunc();
		}
		else {
			materialcost = ratenum * weight;
			matcostext.setText(new DecimalFormat("0.5").format(materialcost));
			_totalcostfunc();
		}
	}
	
	
	public void _labourCostCalc() {
		if (spCostOne.isChecked()) {
			labourCost = (pathLengthnum * (labourThik * labourRate)) + (labourStartPoint * 1);
			labourCosttxt.setText(String.valueOf(labourCost));
			labourcosttotal.setText(String.valueOf(labourCost));
			_totalcostfunc();
		}
		else {
			labourCost = (pathLengthnum * (labourThik * labourRate)) + (labourStartPoint * 2);
			labourCosttxt.setText(String.valueOf(labourCost));
			labourcosttotal.setText(String.valueOf(labourCost));
			_totalcostfunc();
		}
	}
	
	
	public void _totalcostfunc() {
		materialcost = Double.parseDouble(matcostext.getText().toString());
		labourCost = Double.parseDouble(labourcosttotal.getText().toString());
		bendingCost = Double.parseDouble(bendingcost.getText().toString());
		totalcostofquotation = materialcost + (powdercoating_cost + (fab_cost + (labourCost + (bendingCost + other_charges))));
		totalcost.setText(new DecimalFormat("0.5").format(totalcostofquotation));
	}
	
	
	public void _bendcostcalc() {
		totalbendrate = bend_qty * bend_rate;
		bendingcost.setText(String.valueOf(totalbendrate));
		_totalcostfunc();
	}
	
	
	public void _sqftcalc() {
		sqft = (lengthnum * widthnum) / 92903;
		sqfttxt.setText(new DecimalFormat("0.5").format(sqft));
	}
	
	
	public void _powder_coating_cost_calc() {
		powdercoating_cost = sqft * (2 * powcoat_rate);
		powcoattext.setText(new DecimalFormat("0.5").format(powdercoating_cost));
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}