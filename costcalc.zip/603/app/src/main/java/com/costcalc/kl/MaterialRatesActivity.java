package com.costcalc.kl;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.FirebaseApp;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class MaterialRatesActivity extends AppCompatActivity {
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear12;
	private LinearLayout linear14;
	private LinearLayout linear16;
	private LinearLayout linear18;
	private LinearLayout linear20;
	private LinearLayout linear22;
	private Button button1;
	private Button button2;
	private LinearLayout linear9;
	private EditText mscr;
	private TextView textview1;
	private LinearLayout linear13;
	private EditText mshr;
	private TextView textview3;
	private LinearLayout linear15;
	private EditText ss304;
	private TextView textview4;
	private LinearLayout linear17;
	private EditText ss316;
	private TextView textview5;
	private LinearLayout linear19;
	private EditText ss202;
	private TextView textview6;
	private LinearLayout linear21;
	private EditText alu;
	private TextView textview7;
	private LinearLayout linear23;
	private EditText gi;
	private TextView textview8;
	
	private SharedPreferences material;
	private Intent i = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.material_rates);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear12 = findViewById(R.id.linear12);
		linear14 = findViewById(R.id.linear14);
		linear16 = findViewById(R.id.linear16);
		linear18 = findViewById(R.id.linear18);
		linear20 = findViewById(R.id.linear20);
		linear22 = findViewById(R.id.linear22);
		button1 = findViewById(R.id.button1);
		button2 = findViewById(R.id.button2);
		linear9 = findViewById(R.id.linear9);
		mscr = findViewById(R.id.mscr);
		textview1 = findViewById(R.id.textview1);
		linear13 = findViewById(R.id.linear13);
		mshr = findViewById(R.id.mshr);
		textview3 = findViewById(R.id.textview3);
		linear15 = findViewById(R.id.linear15);
		ss304 = findViewById(R.id.ss304);
		textview4 = findViewById(R.id.textview4);
		linear17 = findViewById(R.id.linear17);
		ss316 = findViewById(R.id.ss316);
		textview5 = findViewById(R.id.textview5);
		linear19 = findViewById(R.id.linear19);
		ss202 = findViewById(R.id.ss202);
		textview6 = findViewById(R.id.textview6);
		linear21 = findViewById(R.id.linear21);
		alu = findViewById(R.id.alu);
		textview7 = findViewById(R.id.textview7);
		linear23 = findViewById(R.id.linear23);
		gi = findViewById(R.id.gi);
		textview8 = findViewById(R.id.textview8);
		material = getSharedPreferences("rates", Activity.MODE_PRIVATE);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				material.edit().putString("mscr", mscr.getText().toString()).commit();
				material.edit().putString("mshr", mshr.getText().toString()).commit();
				material.edit().putString("ss304", ss304.getText().toString()).commit();
				material.edit().putString("ss316", ss316.getText().toString()).commit();
				material.edit().putString("ss202", ss202.getText().toString()).commit();
				material.edit().putString("alu", alu.getText().toString()).commit();
				material.edit().putString("gi", gi.getText().toString()).commit();
				SketchwareUtil.showMessage(getApplicationContext(), "Saved.!");
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), ViewRatesActivity.class);
				startActivity(i);
			}
		});
	}
	
	private void initializeLogic() {
		mscr.setText(material.getString("mscr", ""));
		mshr.setText(material.getString("mshr", ""));
		ss304.setText(material.getString("ss304", ""));
		ss316.setText(material.getString("ss316", ""));
		ss202.setText(material.getString("ss202", ""));
		alu.setText(material.getString("alu", ""));
		gi.setText(material.getString("gi", ""));
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}