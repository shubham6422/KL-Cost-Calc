package com.costcalc.kl;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.FirebaseApp;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class ViewRatesActivity extends AppCompatActivity {
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear10;
	private LinearLayout linear12;
	private LinearLayout linear14;
	private LinearLayout linear16;
	private LinearLayout linear18;
	private LinearLayout linear20;
	private LinearLayout linear9;
	private TextView mscr_txt;
	private TextView textview1;
	private LinearLayout linear11;
	private TextView mshr_txt;
	private TextView textview4;
	private LinearLayout linear13;
	private TextView ss304_txt;
	private TextView textview6;
	private LinearLayout linear15;
	private TextView ss316_txt;
	private TextView textview8;
	private LinearLayout linear17;
	private TextView ss202_txt;
	private TextView textview10;
	private LinearLayout linear19;
	private TextView alu_txt;
	private TextView textview12;
	private LinearLayout linear21;
	private TextView gi_txt;
	private TextView textview14;
	
	private SharedPreferences material;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.view_rates);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear10 = findViewById(R.id.linear10);
		linear12 = findViewById(R.id.linear12);
		linear14 = findViewById(R.id.linear14);
		linear16 = findViewById(R.id.linear16);
		linear18 = findViewById(R.id.linear18);
		linear20 = findViewById(R.id.linear20);
		linear9 = findViewById(R.id.linear9);
		mscr_txt = findViewById(R.id.mscr_txt);
		textview1 = findViewById(R.id.textview1);
		linear11 = findViewById(R.id.linear11);
		mshr_txt = findViewById(R.id.mshr_txt);
		textview4 = findViewById(R.id.textview4);
		linear13 = findViewById(R.id.linear13);
		ss304_txt = findViewById(R.id.ss304_txt);
		textview6 = findViewById(R.id.textview6);
		linear15 = findViewById(R.id.linear15);
		ss316_txt = findViewById(R.id.ss316_txt);
		textview8 = findViewById(R.id.textview8);
		linear17 = findViewById(R.id.linear17);
		ss202_txt = findViewById(R.id.ss202_txt);
		textview10 = findViewById(R.id.textview10);
		linear19 = findViewById(R.id.linear19);
		alu_txt = findViewById(R.id.alu_txt);
		textview12 = findViewById(R.id.textview12);
		linear21 = findViewById(R.id.linear21);
		gi_txt = findViewById(R.id.gi_txt);
		textview14 = findViewById(R.id.textview14);
		material = getSharedPreferences("rates", Activity.MODE_PRIVATE);
	}
	
	private void initializeLogic() {
		mscr_txt.setText(material.getString("mscr", ""));
		mshr_txt.setText(material.getString("mshr", ""));
		ss304_txt.setText(material.getString("ss304", ""));
		ss316_txt.setText(material.getString("ss316", ""));
		ss202_txt.setText(material.getString("ss202", ""));
		alu_txt.setText(material.getString("alu", ""));
		gi_txt.setText(material.getString("gi", ""));
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}